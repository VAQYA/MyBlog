export default {
  all: '全部',
  article: '文章',
  tag: 'ラベル',
  category: '分類',
  friendLink: '友情リンク',
  timeLine: 'タイムライン',
  timeLineMsg: '昨日また！'
}
