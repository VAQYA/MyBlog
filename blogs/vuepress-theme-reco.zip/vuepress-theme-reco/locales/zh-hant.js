export default {
  all: '全部',
  article: '文章',
  tag: '標簽',
  category: '分類',
  friendLink: '友情鏈接',
  timeLine: '時間軸',
  timeLineMsg: '昨日重現！'
}
