export default {
  all: '전체',
  article: '글',
  tag: '태그',
  category: '분류',
  friendLink: '링크 참조',
  timeLine: '타임 라인',
  timeLineMsg: '어제 또!'
}
