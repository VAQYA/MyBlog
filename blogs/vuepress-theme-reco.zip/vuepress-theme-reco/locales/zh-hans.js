export default {
  all: '全部',
  article: '文章',
  tag: '标签',
  category: '分类',
  friendLink: '友情链接',
  timeLine: '时间轴',
  timeLineMsg: '昨日重现！'
}
