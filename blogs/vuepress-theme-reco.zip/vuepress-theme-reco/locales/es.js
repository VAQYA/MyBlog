export default {
  all: 'Todas',
  article: 'Artículos',
  tag: 'Etiquetas',
  category: 'Categorías',
  friendLink: 'Páginas amigas',
  timeLine: 'Cronología',
  timeLineMsg: '¡Ayer otra vez!'
}
