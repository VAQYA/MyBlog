export default {
  all: 'All',
  article: 'Articles',
  tag: 'Tags',
  category: 'Categories',
  friendLink: 'Friend Links',
  timeLine: 'TimeLine',
  timeLineMsg: 'Yesterday Once More!'
}
